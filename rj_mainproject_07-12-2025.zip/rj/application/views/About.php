
        <div class="slider bg-navy-blue bg-fixed pos-rel breadcrumbs-page">
            <div class="container">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#"><i class="icofont-home"></i></a></li>
                    
                        <li class="breadcrumb-item active" aria-current="page">About Us</li>
                    </ol>
                </nav>
                <h1>About Us</h1>
                
            </div>
        </div>
        <main id="body-content">
            <section class="wide-tb-80">
                <div class="container pos-rel">
                    <div class="row align-items-center">
                        <div class="col-md-6 wow fadeInLeft" data-wow-duration="0" data-wow-delay="0s">
                            <h2 class="mb-4 fw-7 txt-blue">
                                About <span class="fw-6 txt-orange">Rajlaxmi Roadlines</span>
                            </h2>
                            <p>As a part of our service offering, we provide end to end logistics management as our flagship offering. It is a complete packaged solution that takes care of loading, unloading, manpower needs, transportation and responsibilty of the goods being transported.
                            </p>
                            <p>We offer a complete spectrum of integrated logistics services that includes only Land logistics. These are backed with a host of support services like road/rail transport.
                            </p>
                        </div>
                        <div class="col-md-6 wow fadeInRight" data-wow-duration="0" data-wow-delay="0s">
                            <img src="<?php echo base_url();?>assets/images/map-bg-orange.jpg" alt>
                        </div>
                    </div>
                </div>
            </section>
            
            
            
            <section class="pos-rel bg-light-theme">
                <div class="container-fluid">
                    <div class="row align-items-center">
                        <div class="col-lg-5 col-12 p-0">
                            <img src="<?php echo base_url();?>assets/images/why-choose-us.jpg" class="w-100" alt>
                        </div>
                        <div class="col-lg-6 col-12">
                            <div class="p-5 about-whoose">
                                <h1 class="heading-main text-start mb-4">
                                    <span>Why Choose</span>
                                    Rajlaxmi Roadlines
                                </h1>
                                <ul class="list-unstyled icons-listing theme-orange w-half mb-0">
                                    <li class="wow fadeInUp" data-wow-duration="0" data-wow-delay="0s"><i class="icofont-check"></i>Deliver Environmentally Responsible Client Services</li>
                                    <li class="wow fadeInUp" data-wow-duration="0" data-wow-delay="0.1s"><i class="icofont-check"></i>Be an Active Community Partner</li>
                                    <li class="wow fadeInUp" data-wow-duration="0" data-wow-delay="0.2s"><i class="icofont-check"></i>Drive Continuous Improvement</li>
                                    <li class="wow fadeInUp" data-wow-duration="0" data-wow-delay="0.3s"><i class="icofont-check"></i>Clearance and compliance service</li>
                                    
                                    <li class="wow fadeInUp" data-wow-duration="0" data-wow-delay="0.5s"><i class="icofont-check"></i>Maintain High Ethical Standards</li>
                                    <li class="wow fadeInUp" data-wow-duration="0" data-wow-delay="0.6s"><i class="icofont-check"></i>Air & Ocean Cargo Insurance</li>
                                    <li class="wow fadeInUp" data-wow-duration="0" data-wow-delay="0.7s"><i class="icofont-check"></i>We ensure complete security</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            
            
           <!--  <section class="wide-tb-100 bg-fixed clients-bg pos-rel">
                <div class="bg-overlay blue opacity-80"></div>
                <div class="container">
                    <div class="wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">
                        <h1 class="heading-main">
                            <span>SOME OF OUR</span>
                            Clients
                        </h1>
                    </div>
                    <div class="row">
                        <div class="col-sm-12 wow fadeInUp" data-wow-duration="0" data-wow-delay="0.2s">
                            <div class="owl-carousel owl-theme" id="home-clients">
                                <div class="item">
                                    <img src="<?php echo base_url();?>assets/images/clients/client1.png" alt>
                                </div>
                                <div class="item">
                                    <img src="<?php echo base_url();?>assets/images/clients/client2.png" alt>
                                </div>
                                <div class="item">
                                    <img src="<?php echo base_url();?>assets/images/clients/client3.png" alt>
                                </div>
                                <div class="item">
                                    <img src="<?php echo base_url();?>assets/images/clients/client4.png" alt>
                                </div>
                                <div class="item">
                                    <img src="<?php echo base_url();?>assets/images/clients/client5.png" alt>
                                </div>
                                <div class="item">
                                    <img src="<?php echo base_url();?>assets/images/clients/client6.png" alt>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section> -->
            
            <section class="wide-tb-80 bg-navy-blue callout-style-1 wow fadeInUp" data-wow-duration="0" data-wow-delay="0s">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-4 col-md-12 mb-0">
                    <h4 class="h4-xl">Interested in working with Rajlaxmi Roadlines?</h4>
                </div>
                <div class="col">
                    <div class="center-text">
                        Our approach involves personalized, consultative management of suppliers.
                    </div>
                </div>
                <div class="col-sm-auto">
                    <a href="<?php echo base_url();?>contact_us" class="btn-theme bg-white light">Get In Touch <i class="icofont-rounded-right"></i></a>
                </div>
            </div>
        </div>
    </section>
        </main>
        
        