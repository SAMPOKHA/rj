<div class="slider bg-navy-blue bg-fixed pos-rel breadcrumbs-page">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><i class="icofont-home"></i></a></li>
                
                <li class="breadcrumb-item active" aria-current="page">Our Services</li>
            </ol>
        </nav>
        <h1>Our Services</h1>
        
    </div>
</div>
<main id="body-content">
    <section class="wide-tb-80 bg-fixed what-we-offer">
        <div class="container pos-rel">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h2 class="mb-4 fw-7 txt-blue wow fadeInLeft" data-wow-duration="0" data-wow-delay="0s">
                        Quality <span class="fw-6 txt-orange">and</span> Performance <br><span class="fw-6 txt-orange">at the right price</span>
                    </h2>
                    <p class="wow fadeInLeft" data-wow-duration="0" data-wow-delay="0.2s">We have Our Self vehicle Like TATA S , Mahindra Pickup, TATA 407 tempo , TATA LPT 909 , LPT 1109 ,ODC Trucks , Etc and many other vehicle are attached to our firm , in any condition we will Provide you the better transportation other than the competitors.

                    </p>
                    <p class="wow fadeInLeft" data-wow-duration="0" data-wow-delay="0.4s">We are Already providing  the service to Agility Logistics Pvt Ltd , C.H Robinson Worldwide ,Avignon Shipping Company , etc many other CHA Companies ,we are known for the better Transport service  into the Companies 
                    </p>
                </div>
                <div class="col-md-6"></div>
            </div>
        </div>
    </section>
    
    <section class="bg-light-theme wide-tb-100">
        <div class="container pos-rel">
            <div class="row">
                <div class="col-sm-12 wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">
                    <h1 class="heading-main">
                        <span>Our Main Services</span>
                        What Makes Us Special
                    </h1>
                </div>
                <div class="col-lg-6 ms-auto">
                    <div class="row">
                        <div class="col-12 wow fadeInUp" data-wow-duration="0" data-wow-delay="0s">
                            <div class="icon-box-3 mb-5 bg-light-theme">
                                <div class="media">
                                    <div class="service-icon mr-5">
                                        <i class="icofont-box"></i>
                                    </div>
                                    <div class="service-inner-content media-body">
                                        <h4 class="h4-md">STEEL CARGO MOVEMENT</h4>
                                        <p>Our specialization in STEEL Cargo includes,
<ul>
  <li>Steel coils</li>
  <li>Angel channels</li>
  <li>Plates</li>
  <li>Machine dies</li>
</ul>

                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 wow fadeInUp" data-wow-duration="0" data-wow-delay="0.2s">
                            <div class="icon-box-3 mb-5 bg-light-theme">
                                <div class="media">
                                    <div class="service-icon mr-5">
                                        <i class="icofont-shield"></i>
                                    </div>
                                    <div class="service-inner-content media-body">
                                        <h4 class="h4-md">ODC CONSIGNMENTS</h4>
                                        <p>Our specialization in ODC includes,
<ul>
  <li>Heavy Machineries</li>
  <li>Wind Mill Equipments</li>
  <li>Heavy-duty Cranes</li>
  <li>Heavy Lifts</li>
</ul>




                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 wow fadeInUp" data-wow-duration="0" data-wow-delay="0.4s">
                            <div class="icon-box-3 bg-light-theme">
                                <div class="media">
                                    <div class="service-icon mr-5">
                                        <i class="icofont-tree-alt"></i>
                                    </div>
                                    <div class="service-inner-content media-body">
                                        <h4 class="h4-md">PARTIAL LOAD SERVICE</h4>
                                        <p><ul>
  <li>Timely Customer Service assistance.</li>
  <li>Reserving various goods, ranging from lightweight to heavy, in diverse shapes and packaging.</li>
  <li>Convenient online pickup requests.</li>
  <li>Operations extending to over 2100 established locations throughout India managed by the Company.</li>
  <li>Dispatch scheduling and fixed route operations driven by systematic approaches.</li>
  <li>Cutting-edge technology solutions integrated with digitalized customer interface documents.</li>
  <li>Secure, punctual, and efficient services.</li>
</ul>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="img-business-man">
                    <img src="<?php echo base_url();?>assets/images/courier-man.png" alt>
                </div>
            </div>
        </div>
    </section>
    
    
    
    <section class="wide-tb-80 bg-navy-blue callout-style-1 wow fadeInUp" data-wow-duration="0" data-wow-delay="0s">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-4 col-md-12 mb-0">
                    <h4 class="h4-xl">Interested in working with Rajlaxmi Roadlines?</h4>
                </div>
                <div class="col">
                    <div class="center-text">
                        Our approach involves personalized, consultative management of suppliers.
                    </div>
                </div>
                <div class="col-sm-auto">
                    <a href="<?php echo base_url();?>contact_us" class="btn-theme bg-white light">Get In Touch <i class="icofont-rounded-right"></i></a>
                </div>
            </div>
        </div>
    </section>