<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="viewport" content="width=device-width, initial-scale=1.0 user-scalable=no" />
        <title>Rajlaxmi Roadlines</title>
        <meta name="author" content="Mannat Studio">
        <meta name="description" content="Rajlaxmi Roadlines is a Logistic and Cargo related services.">
        <meta name="keywords" content="Rajlaxmi Roadlines,business, cargo, chain supply, company, corporate, expedition, freight, logistics, packaging, services, shipping, transport, transportation, trucking, warehousing">
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url();?>assets/images/favicon.ico">
        <link href="<?php echo base_url();?>assets/css/theme-plugins.min.css" rel="stylesheet">
        <link href="<?php echo base_url();?>assets/css/style.css" rel="stylesheet">
        <link href="<?php echo base_url();?>assets/css/responsive.css" rel="stylesheet">
        <link href="
https://cdn.jsdelivr.net/npm/@icon/icofont@1.0.1-alpha.1/icofont.min.css
" rel="stylesheet">

        <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png">

<link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png">



<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/revolution/css/layers.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/revolution/css/navigation.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/revolution/css/settings.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/revolution/fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/revolution/fonts/font-awesome/css/font-awesome.css">
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        <div id="pageloader">
            <div class="loader-item">
                <div class="loader">
                    <div class="spin"></div>
                    <div class="bounce"></div>
                </div>
            </div>
        </div>
        <header>
            <div class="top-bar d-flex align-items-center text-md-left">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col">
                            <i class="icofont-google-map"></i> Sai Dham Commercial mall,Bhosari pune -411039 <span class="counter">0</span>
                        </div>
                        <div class="col-md-auto">
                            <span class="me-3"><i class="icofont-ui-touch-phone"></i> +02 030 714 237</span>
                            <span class="me-3"><i class="icofont-ui-email"></i> support@rajlaxmiroadlines.com</span>
                            
                        </div>
                    </div>
                </div>
            </div>
            <nav class="header-fullpage navbar navbar-expand-lg">
                <div class="container">
                    <a class="navbar-brand" href="<?php echo base_url();?>"><img src="<?php echo base_url();?>assets/images/logo.png" alt></a>
                    <div class="d-flex order-lg-last align-items-center request-btn">
                        
                        <a class="btn-theme icon-left bg-navy-blue no-shadow align-self-center" href="<?php echo base_url();?>contact_us" role="button"><i class="icofont-list"></i><span class="d-none d-sm-inline-block"> Request Quote</span></a>
                        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        </button>
                    </div>
                    <div class="navbar-collapse offcanvas offcanvas-start offcanvas-collapse" id="navbarCollapse">
                        <div class="offcanvas-header">
                            <a class="navbar-brand" href="index.html"><img src="<?php echo base_url();?>assets/images/logo_footer.svg" alt></a>
                            <button class="navbar-toggler x collapsed" type="button" data-bs-toggle="offcanvas" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                            <i class="icofont-close-line"></i>
                            </button>
                        </div>
                        <div class="offcanvas-body w-100">
                            <ul class="navbar-nav ms-auto mb-2 mb-md-0">
                                <li class="nav-item dropdown">
                                    <a class="nav-link" href="<?php echo base_url();?>">Home <i class="icofont-rounded-down"></i></a>
                                    
                                </li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link" href="<?php echo base_url();?>about_us">About Us <i class="icofont-rounded-down"></i></a>
                                    
                                </li>

                                <li class="nav-item dropdown">
                                    <a class="nav-link" href="<?php echo base_url();?>services">Services <i class="icofont-rounded-down"></i></a>
                                    
                                </li>

                                <!-- <li class="nav-item dropdown">
                                    <a class="nav-link" href="<?php echo base_url();?>project">Projects <i class="icofont-rounded-down"></i></a>
                                   
                                </li> -->
                                
                                <li class="nav-item dropdown">
                                    <a class="nav-link" href="<?php echo base_url();?>contact_us">Contact <i class="icofont-rounded-down"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>
        </header>


