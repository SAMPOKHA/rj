<footer class="wide-tb-70 bg-light-theme pb-0">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="logo-footer">
                            <img src="assets/images/logo_footer.svg" alt>
                        </div>
                        <p>As a part of our service offering, we provide end to end logistics management as our flagship offering. It is a complete packaged solution that takes care of loading, unloading, manpower needs, transportation and responsibilty of the goods being transported.
                        </p>
                        <!-- <h3 class="footer-heading">We're Social</h3>
                        <div class="social-icons">
                            <a href="#"><i class="icofont-facebook"></i></a>
                            <a href="#"><i class="icofont-twitter"></i></a>
                            <a href="#"><i class="icofont-whatsapp"></i></a>
                            <a href="#"><i class="icofont-youtube-play"></i></a>
                        </div> -->
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <h3 class="footer-heading">Quick Navigation</h3>
                        <div class="footer-widget-menu">
                            <ul class="list-unstyled">
                                <li><a href="<?php echo base_url();?>"><i class="icofont-simple-right"></i> <span>Home</span></a></li>
                                <li><a href="<?php echo base_url();?>about_us"><i class="icofont-simple-right"></i> <span>About us</span></a></li>
                               
                                <li><a href="<?php echo base_url();?>services"><i class="icofont-simple-right"></i> <span>Services</span></a></li>
                                <li><a href="<?php echo base_url();?>contact_us"><i class="icofont-simple-right"></i> <span>Contacts</span></a></li>
                                <li><a href="<?php echo base_url();?>Privacy_policy"><i class="icofont-simple-right"></i> <span>Privacy Policy</span></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <h3 class="footer-heading">Get In Touch</h3>
                        <div class="footer-widget-contact">
                            <div class="media mb-3">
                                <i class="icofont-google-map me-3"></i>
                                <div class="media-body">Sai Dham Commercial mall , 2 nd Floor , Office No -45
 ,Landewadi road Bhosari pune -411039

                                </div>
                            </div>
                            <div class="media mb-3">
                                <i class="icofont-smart-phone me-3"></i>
                                <div class="media-body">
                                    <div>+91 860 043 1111 </div>
                                    <div>+91 909 602 0389 </div>
                                </div>
                            </div>
                            <div class="media mb-3">
                                <i class="icofont-ui-email me-3"></i>
                                <div class="media-body">
                                    <div><a href="#"><span class="__cf_email__">support.rajlaxmiroadlines.com</span></a></div>
                                    
                                    <div><a href="#"><span class="__cf_email__">maroti.rajlaxmiroadlines.com</span></a></div>
                                </div>
                            </div>
                            <div class="media mb-3">
                                <i class="icofont-clock-time me-3"></i>
                                <div class="media-body">
                                    <div><strong>Mon - Sat</strong></div>
                                    <div>10:00 Am - 6:00 PM EST</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
            <div class="copyright-wrap bg-navy-blue wide-tb-30">
                <div class="container">
                    <div class="row text-md-start text-center">
                        <div class="col-sm-12 col-md-6 copyright-links">
                            <a href="<?php echo base_url();?>Privacy_policy">Privacy Policy</a> <span>|</span> <a href="<?php echo base_url();?>contact_us">Contact</a> 
                        </div>
                        <div class="col-sm-12 col-md-6 text-md-end text-center">
                            Designed by <a href="#" rel="nofollow">SampurnSolutions</a> © <span id="yearText"></span> All Rights Reserved
                        </div>
                    </div>
                </div>
            </div>
        </footer>
       
        
        
        
        

<div class="overlay overlay-hugeinc">
<form class="form-inline mt-2 mt-md-0">
<div class="form-inner">
<div class="form-inner-div d-inline-flex align-items-center no-gutters">
<div class="col-auto">
<i class="icofont-search"></i>
</div>
<div class="col">
<input class="form-control w-100 p-0" type="text" placeholder="Search" aria-label="Search">
</div>
<div class="col-auto">
<a href="#" class="overlay-close link-oragne"><i class="icofont-close-line"></i></a>
</div>
</div>
</div>
</form>
</div>


<div class="modal fade" id="request_popup" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered request_popup modal-xl modal-dialog-scrollable" role="document">
<div class="modal-content">
<div class="modal-body p-0">

<section class="pos-rel bg-light-gray">
<div class="container-fluid p-0">
<a href="#" class="close" data-bs-dismiss="modal" aria-label="Close">
<i class="icofont-close-line"></i>
</a>
<div class="d-lg-flex justify-content-end no-gutters mb-spacer-md">
<div class="col bg-fixed bg-img-7 request_pag_img">
&nbsp;
</div>
<div class="col-lg-7 col-12">
<div class="form-content">
<h2 class="h2-xl mb-4 fw-6 txt-orange">Request A Quote</h2>
<form action="#" method="post" novalidate="novalidate" class="rounded-field">
<div class="row g-3 mb-4">
<div class="col-md">
<select title="Please choose a package" required name="package" class="form-control wide" aria-required="true" aria-invalid="false">
<option value>Freight Type</option>
<option value="Type 1">Type 1</option>
<option value="Type 2">Type 2</option>
<option value="Type 3">Type 3</option>
<option value="Type 4">Type 4</option>
</select>
</div>
<div class="col-md">
<select title="Please choose a package" required name="package" class="form-control wide" aria-required="true" aria-invalid="false">
<option value>Incoterms</option>
<option value="Type 1">Type 1</option>
<option value="Type 2">Type 2</option>
<option value="Type 3">Type 3</option>
<option value="Type 4">Type 4</option>
</select>
</div>
</div>
<div class="row g-3 mb-4">
<div class="col-md">
<input type="text" name="name" class="form-control" placeholder="City of departure">
</div>
<div class="col-md">
<input type="text" name="email" class="form-control" placeholder="Delivery city">
</div>
</div>
<div class="row g-3 mb-4">
<div class="col-md">
<input type="text" name="name" class="form-control" placeholder="Total gross weight (KG)">
</div>
<div class="col-md">
<input type="text" name="email" class="form-control" placeholder="Dimension">
</div>
</div>
<div class="form-row">
<div class="col-md">
<div class="center-head"><span class="bg-light-gray txt-orange">Your
Personal Details</span></div>
</div>
</div>
<div class="row g-3 mb-4">
<div class="col-md">
<input type="text" name="name" class="form-control mb-3" placeholder="Your Name">
<input type="text" name="name" class="form-control mb-3" placeholder="Email">
<input type="text" name="name" class="form-control" placeholder="Phone Number">
</div>
<div class="col-md">
<textarea rows="7" placeholder="Message" class="form-control"></textarea>
</div>
</div>
<div class="form-row">
<div class="col pt-3">
<button type="submit" class="form-btn btn-theme bg-orange">Send
Message <i class="icofont-rounded-right"></i></button>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</section>

</div>
</div>
</div>
</div>


<a id="mkdf-back-to-top" href="#" class="off"><i class="icofont-rounded-up"></i></a>


<div class="b-settings-panel active">
<h5>Color Scheme</h5>
<div class="settings-section color-list">
<div class="items color_shade_default active" data-src="assets/css/themes/color_shade_1.css"><img src="assets/color-theme/color_theme_1.png" alt></div>
<div class="items color_shade_1" data-src="assets/css/themes/color_shade_2.css"><img src="assets/color-theme/color_theme_2.png" alt></div>
<div class="items color_shade_2" data-src="assets/css/themes/color_shade_3.css"><img src="assets/color-theme/color_theme_3.png" alt></div>
<div class="items color_shade_3" data-src="assets/css/themes/color_shade_4.css"><img src="assets/color-theme/color_theme_4.png" alt></div>
<div class="items color_shade_4" data-src="assets/css/themes/color_shade_5.css"><img src="assets/color-theme/color_theme_5.png" alt></div>
<div class="items color_shade_5" data-src="assets/css/themes/color_shade_6.css"><img src="assets/color-theme/color_theme_6.png" alt></div>
<div class="items color_shade_6" data-src="assets/css/themes/color_shade_7.css"><img src="assets/color-theme/color_theme_7.png" alt></div>
<div class="items color_shade_7" data-src="assets/css/themes/color_shade_8.css"><img src="assets/color-theme/color_theme_8.png" alt></div>
<div class="items color_shade_7" data-src="assets/css/themes/color_shade_9.css"><img src="assets/color-theme/color_theme_9.png" alt></div>
<div class="items color_shade_7" data-src="assets/css/themes/color_shade_10.css"><img src="assets/color-theme/color_theme_10.png" alt></div>
</div>
<a class="btn btn-outline-secondary btn-block reset mt-4" data-src="assets/css/style.css" href="javascript:void(0)">Reset</a>
<div class="btn-settings"></div>
</div>


<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/jquery.min.js"></script>
<script src="assets/js/theme-plugins.min.js"></script>
<script src="assets/twitter/jquery.tweet.js"></script>

<script type="text/javascript" src="assets/revolution/js/jquery.themepunch.tools.min.js"></script>
<script type="text/javascript" src="assets/revolution/js/jquery.themepunch.revolution.min.js"></script>

<script type="text/javascript" src="assets/revolution/js/extensions/revolution.extension.actions.min.js"></script>
<script type="text/javascript" src="assets/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
<script type="text/javascript" src="assets/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
<script type="text/javascript" src="assets/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script type="text/javascript" src="assets/revolution/js/extensions/revolution.extension.migration.min.js"></script>
<script type="text/javascript" src="assets/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
<script type="text/javascript" src="assets/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
<script type="text/javascript" src="assets/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
<script type="text/javascript" src="assets/revolution/js/extensions/revolution.extension.video.min.js"></script>

<script src="assets/js/site-custom.js"></script>
<script type="text/javascript">
        var tpj = jQuery;

        var revapi1078;
        tpj(document).ready(function () {
            if (tpj("#rev_slider_1078_1").revolution == undefined) {
                revslider_showDoubleJqueryError("#rev_slider_1078_1");
            } else {
                revapi1078 = tpj("#rev_slider_1078_1").show().revolution({
                    sliderType: "standard",
                    jsFileLocation: "revolution/js/",
                    sliderLayout: "fullscreen",
                    dottedOverlay: "none",
                    delay: 9000,
                    navigation: {
                        keyboardNavigation: "off",
                        keyboard_direction: "horizontal",
                        mouseScrollNavigation: "off",
                        mouseScrollReverse: "default",
                        onHoverStop: "off",
                        touch: {
                            touchenabled: "on",
                            swipe_threshold: 75,
                            swipe_min_touches: 1,
                            swipe_direction: "horizontal",
                            drag_block_vertical: false
                        }
                        ,
                        arrows: {
                            style: "metis",
                            enable: true,
                            hide_onmobile: true,
                            hide_under: 600,
                            hide_onleave: true,
                            hide_delay: 200,
                            hide_delay_mobile: 1200,
                            //tmp:'<div class="tp-title-wrap">    <div class="tp-arr-imgholder"></div> </div>',
                            left: {
                                h_align: "left",
                                v_align: "center",
                                h_offset: 30,
                                v_offset: 0
                            },
                            right: {
                                h_align: "right",
                                v_align: "center",
                                h_offset: 30,
                                v_offset: 0
                            }
                        }
                        ,
                        bullets: {
                            style: 'hades',
                            tmp: '<span class="tp-bullet-image"></span>',
                            enable: false,
                            hide_onmobile: true,
                            hide_under: 600,
                            //style:"metis",
                            hide_onleave: true,
                            hide_delay: 200,
                            hide_delay_mobile: 1200,
                            direction: "horizontal",
                            h_align: "center",
                            v_align: "bottom",
                            h_offset: 0,
                            v_offset: 30,
                            space: 5,
                            //tmp:'<span class="tp-bullet-img-wrap">  <span class="tp-bullet-image"></span></span><span class="tp-bullet-title">{{title}}</span>'
                        }
                    },
                    viewPort: {
                        enable: true,
                        outof: "pause",
                        visible_area: "80%",
                        presize: false
                    },
                    responsiveLevels: [1240, 1024, 778, 480],
                    visibilityLevels: [1240, 1024, 778, 480],
                    gridwidth: [1240, 1024, 778, 480],
                    gridheight: [600, 600, 500, 400],
                    lazyType: "none",
                    parallax: {
                        type: "mouse",
                        origo: "slidercenter",
                        speed: 2000,
                        levels: [2, 3, 4, 5, 6, 7, 12, 16, 10, 50, 47, 48, 49, 50, 51, 55],
                        type: "mouse",
                    },
                    shadow: 0,
                    spinner: 'spinner2',
                    stopLoop: "off",
                    stopAfterLoops: -1,
                    stopAtSlide: -1,
                    shuffle: "off",
                    autoHeight: "off",
                    hideThumbsOnMobile: "off",
                    hideSliderAtLimit: 0,
                    hideCaptionAtLimit: 0,
                    hideAllCaptionAtLilmit: 0,
                    debugMode: false,
                    fallbacks: {
                        simplifyAll: "off",
                        nextSlideOnWindowFocus: "off",
                        disableFocusListener: false,
                    }
                });
            }
        }); /*ready*/
    </script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vef91dfe02fce4ee0ad053f6de4f175db1715022073587" integrity="sha512-sDIX0kl85v1Cl5tu4WGLZCpH/dV9OHbA4YlKCuCiMmOQIk4buzoYDZSFj+TvC71mOBLh8CDC/REgE0GX0xcbjA==" data-cf-beacon='{"rayId":"88cf6b4f8e589ebf","r":1,"version":"2024.4.1","token":"64224fc8786846928480d180dfc466bd"}' crossorigin="anonymous"></script>
</body>
</html>