<div class="slider bg-navy-blue bg-fixed pos-rel breadcrumbs-page">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><i class="icofont-home"></i></a></li>
                <li class="breadcrumb-item active" aria-current="page">Privacy Policy</li>
            </ol>
        </nav>
        <h1>Privacy Policy</h1>
    </div>
</div>
<main id="body-content">
    <section class="wide-tb-80">
        <div class="container pos-rel">
            <div class="row align-items-center">
                <div class="col-lg-8 mx-auto col-md-12">
                    <h2 class="mb-4 fw-7 txt-orange">
                        QUALITY POLICY:

                    </h2>
                    <p><ul>
    <li>We are committed to providing safe, dependable transportation service to our customers.</li>
    <li>To meet our goal, we prioritize:</li>
    <ul>
        <li>Prompt & Positive response</li>
        <li>Team Performance</li>
        <li>On-time delivery of goods</li>
        <li>To reduce customer complaints</li>
    </ul>
    <li>With a mission to make continual improvement in all aspects.</li>
</ul>

                    </p>
                </div>
            </div>
        </div>
    </section>
   
    
    
</main>
<section class="wide-tb-80 bg-navy-blue callout-style-1 wow fadeInUp" data-wow-duration="0" data-wow-delay="0s">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-4 col-md-12 mb-0">
                    <h4 class="h4-xl">Interested in working with Rajlaxmi Roadlines?</h4>
                </div>
                <div class="col">
                    <div class="center-text">
                        Our approach involves personalized, consultative management of suppliers.
                    </div>
                </div>
                <div class="col-sm-auto">
                    <a href="<?php echo base_url();?>contact_us" class="btn-theme bg-white light">Get In Touch <i class="icofont-rounded-right"></i></a>
                </div>
            </div>
        </div>
    </section>