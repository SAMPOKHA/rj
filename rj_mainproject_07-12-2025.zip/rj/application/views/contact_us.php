<div class="slider bg-navy-blue bg-fixed pos-rel breadcrumbs-page">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><i class="icofont-home"></i></a></li>
                
                <li class="breadcrumb-item active" aria-current="page">Contact Us</li>
            </ol>
        </nav>
        <h1>Contact Us</h1>
        
    </div>
</div>
<main id="body-content">
    <section class="wide-tb-80 contact-full-shadow">
        <div class="container">
            <div class="contact-map-bg">
                <img src="<?php echo base_url();?>assets/images/map-bg.png" alt>
            </div>
            <div class="row justify-content-between">
                <div class="col-md-6 col-sm-12 col-lg-4 wow fadeInRight" data-wow-duration="0" data-wow-delay="0s">
                    <div class="contact-detail-shadow">
                        <h4>Head Office </h4>
                        <div class="d-flex align-items-start items">
                            <i class="icofont-google-map"></i> <span>BU Bhandari Skyline Plot No -66, Datta Nagar  Dighi Pune </span>
                        </div>
                        <div class="d-flex align-items-start items">
                            <i class="icofont-phone"></i> <span>9096020389 /8600431111</span>
                        </div>
                        <div class="text-nowrap d-flex align-items-start items">
                            <i class="icofont-email"></i> <a href="mailto:support@rajlaxmiroadlines.com"><span class="__cf_email__">support@rajlaxmiroadlines.com
</span></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-12 col-lg-4 wow fadeInLeft" data-wow-duration="0" data-wow-delay="0s">
                    <div class="contact-detail-shadow">
                        <h4>Branch Office</h4>
                        <div class="d-flex align-items-start items">
                            <i class="icofont-google-map"></i> <span>: Sai Dham Commercial mall , 2 nd Floor , Office No -45
 ,Landewadi road Bhosari pune -411039
</span>
                        </div>
                        <div class="d-flex align-items-start items">
                            <i class="icofont-phone"></i> <span>+02030714237</span>
                        </div>
                        <div class="text-nowrap d-flex align-items-start items">
                            <i class="icofont-email"></i> <a href="mailto:maroti@rajlaxmiroadlines.com"><span class="__cf_email__">maroti@rajlaxmiroadlines.com</span></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="wide-tb-100 bg-light-gray pt-0">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-lg-8 mx-auto wow fadeInUp" data-wow-duration="0" data-wow-delay="0s">
                    <div class="free-quote-form contact-page">
                        <h1 class="heading-main mb-4">
                            Get in touch
                        </h1>
                        <form method="POST"
                        action="<?php echo base_url('Home/sendmail')?>" id="contactusForm" novalidate="novalidate" class="col rounded-field">
                            <div class="row g-4 mb-4">
                                <div class="col-md mb-0">
                                    <input type="text" name="name" id="name" class="form-control" placeholder="Your Name">
                                </div>
                                <div class="col-md mb-0">
                                    <input type="email" name="email" id="email" class="form-control" placeholder="Email">
                                </div>
                            </div>
                            <div class="row g-4 mb-4">
                               
                                <div class="col-md mb-0">
                                    <input type="text" name="phone" id="phone" class="form-control" placeholder="Phone">
                                </div>
                            </div>
                            <div class="row g-4 mb-4">
                                <div class="col-md mb-0">
                                    <input type="text" name="request" id="request" class="form-control" placeholder="Request">
                                </div>
                                
                            </div>
                            <div class="row g-4 mb-4">
                                <div class="col-md mb-0">
                                    <textarea rows="7" name="message" id="message" placeholder="Message" class="form-control"></textarea>
                                </div>
                            </div>
                            <div class="form-row text-center">
                                <button name="contactForm" id="contactForm" type="submit" class="form-btn mx-auto btn-theme bg-orange">Submit Now <i class="icofont-rounded-right"></i></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="wide-tb-80 bg-navy-blue callout-style-1 wow fadeInUp" data-wow-duration="0" data-wow-delay="0s">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-4 col-md-12 mb-0">
                    <h4 class="h4-xl">Interested in working with Rajlaxmi Roadlines?</h4>
                </div>
                <div class="col">
                    <div class="center-text">
                        Our approach involves personalized, consultative management of suppliers.
                    </div>
                </div>
                <div class="col-sm-auto">
                    <a href="<?php echo base_url();?>contact_us" class="btn-theme bg-white light">Get In Touch <i class="icofont-rounded-right"></i></a>
                </div>
            </div>
        </div>
    </section>
</main>
