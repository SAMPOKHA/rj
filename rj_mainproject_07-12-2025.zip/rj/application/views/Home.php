<div class="slider bg-navy-blue">
    <div id="rev_slider_1078_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" data-alias="classic4export" data-source="gallery" style="margin:0px auto;background-color:transparent;padding:0px;margin-top:0px;margin-bottom:0px;">
        <div id="rev_slider_1078_1" class="rev_slider fullscreenbanner" style="display:none;" data-version="5.4.1">
            <ul>
                <li data-index="rs-82" data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="Power4.easeOut" data-easeout="Power4.easeOut" data-masterspeed="1000" data-thumb="../../assets/images/waterfal-100x50.jpg" data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1 data-param2 data-param3 data-param4 data-param5 data-param6 data-param7 data-param8 data-param9 data-param10 data-description data-slicey_shadow="0px 0px 50px 0px transparent">
                    <img src="<?php echo base_url();?>assets/images/banner_slider_4.jpg" alt data-bgposition="center center" data-kenburns="on" data-duration="7000" data-ease="Linear.easeNone" data-scalestart="100" data-scaleend="150" data-rotatestart="0" data-rotateend="0" data-blurstart="0" data-blurend="0" data-offsetstart="0 0" data-offsetend="0 0" class="rev-slidebg" data-no-retina>
                    <div class="tp-caption tp-resizeme NotGeneric-Title" id="slide-82-layer-2" data-blendmode="”color-dodge“" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['-70','-70','-70','-70']" data-fontsize="['70','60','60','55']" data-lineheight="['80','70','70','40']" data-width="none" data-height="none" data-whitespace="nowrap" data-type="text" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:200,&quot;speed&quot;:1000,&quot;sfx_effect&quot;:&quot;blockfromleft&quot;,&quot;sfxcolor&quot;:&quot;#ffffff&quot;,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;z:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power4.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">We
                        Are Rajlaxmi Roadlines
                    </div>
                    <div class="tp-caption medium_light_white tp-resizeme" id="slide-82-layer-3" data-blendmode="”color-dodge“" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['-10','-10','-10','-10']" data-width="none" data-height="none" data-whitespace="nowrap" data-type="text" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:500,&quot;speed&quot;:1000,&quot;sfx_effect&quot;:&quot;blockfromleft&quot;,&quot;sfxcolor&quot;:&quot;#ffffff&quot;,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;z:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power4.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-fontsize="['28','28','28','28']" data-lineheight="['34','34','34','50']">From Pickup to
                        Destination
                    </div>
                    <div class="tp-caption tp-resizeme small_light_white " id="slide-82-layer-4" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['60','60','60','60']" data-width="none" data-height="none" data-whitespace="nowrap" data-type="text" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:600,&quot;speed&quot;:1000,&quot;sfx_effect&quot;:&quot;blockfromleft&quot;,&quot;sfxcolor&quot;:&quot;#ffffff&quot;,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;z:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power4.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-fontsize="['16','16','16','13']" data-lineheight="['30','30','30','20']">"Delivering excellence, one journey at a time."




                    </div>
                    
                </li>
                <li data-index="rs-3045" data-transition="zoomout" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="2000" data-thumb="rev-slider/assets/images/datcolor-100x50.jpg" data-rotate="0" data-fstransition="fade" data-fsmasterspeed="1500" data-fsslotamount="7" data-saveperformance="off" data-title="Intro" data-param1 data-param2 data-param3 data-param4 data-param5 data-param6 data-param7 data-param8 data-param9 data-param10 data-description>
                    <img src="<?php echo base_url();?>assets/images/banner_slider_3.jpg" alt data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>
                    <div class="tp-caption NotGeneric-Title tp-resizeme" id="slide-3-layer-1" data-x="left" data-hoffset="60" data-y="center" data-voffset="-120" data-width="['auto','auto','auto','auto']" data-height="['auto','auto','auto','auto']" data-transform_idle="o:1;" data-fontsize="['70','70','70','45']" data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-start="700" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 1; white-space: nowrap;">
                        <span class="slider-small">Ready For Any</span> <br>Obstacle
                    </div>
                    <div class="tp-caption NotGeneric-Title tp-resizeme" id="slide-3-layer-2" data-x="left" data-hoffset="60" data-y="center" data-voffset="10" data-width="['auto','auto','auto','auto']" data-height="['auto','auto','auto','auto']" data-transform_idle="o:1;" data-transform_in="x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-start="1400" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 2; white-space: nowrap; font-size: 18px; line-height: 30px;">"Connecting destinations, bridging distances, delivering reliability: <br>Your trusted transport partner, every mile."
                    </div>
                    
                </li>
            </ul>
            <div class="tp-bannertimer tp-bottom" style="height: 7px; background-color: rgba(255, 255, 255, 0.25);"></div>
        </div>
    </div>
</div>


<main id="body-content">
    <section class="bg-white wide-tb-100">
        <div class="container pos-rel">
            <div class="row">
                <div class="col-md-12 col-lg-6">
                    <p><img src="<?php echo base_url();?>assets/images/years_img.png" alt class="mb-5"></p>
                    <p>Rajlaxmi Roadlines started its operations in Pune 2006. However it was only in 2007 that Rajlaxmi Roadlines was registered as a transportation and logistics provider company. Since inception, Rajlaxmi Roadlines has been providing logistic services in the Maharashtra state.
                    </p>
                    <p>Greater Mumbai municipal like Andheri And Navashiva area is the prime focus of our company for operations. However we also have the required skills, expertise and manpower to operate in each of the Pune And Mumbai.</p>
                    <div class="img-icon mt-4 d-flex align-items-center">
                        <!-- <img src="<?php echo base_url();?>assets/images/team/team-1.jpg"> -->
                        <h3>
                            Rahul Bangar
                            <span>Founder & CEO</span>
                        </h3>
                    </div>
                </div>
                <div class="w-100 spacer-50 d-none d-md-block d-lg-none d-sm-none"></div>
                <div class="col-md-12 col-lg-6">
                    <div class="row">
                        <div class="col-12 col-md-6">
                            <div class="icon-box-6">
                                <i class="icofont-box"></i>
                                <h3 class="h3-xs txt-blue">Packaging and Storage</h3>
                                <p>Packaging and storage ensure product preservation.</p>
                                <a href="#" class="btn-arrow bg-navy-blue"><i class="icofont-swoosh-right"></i></a>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="icon-box-6">
                                <i class="icofont-safety"></i>
                                <h3 class="h3-xs txt-blue">Safety & Quality</h3>
                                <p>Safety and quality are paramount in every aspect of product development and delivery.</p>
                                <a href="#" class="btn-arrow bg-navy-blue"><i class="icofont-swoosh-right"></i></a>
                            </div>
                        </div>
                        <div class="w-100 spacer-50 d-none d-md-block d-lg-block d-sm-none"></div>
                        <div class="col-12 col-md-6">
                            <div class="icon-box-6">
                                <i class="icofont-tree-alt"></i>
                                <h3 class="h3-xs txt-blue">Care for Environment</h3>
                                <p>Protecting environment ensures a sustainable future.</p>
                                <a href="#" class="btn-arrow bg-navy-blue"><i class="icofont-swoosh-right"></i></a>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="icon-box-6">
                                <i class="icofont-delivery-time"></i>
                                <h3 class="h3-xs txt-blue">Delivery On Time</h3>
                                <p>Delivery on time is crucial for customer satisfaction.</p>
                                <a href="#" class="btn-arrow bg-navy-blue"><i class="icofont-swoosh-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="bg-light-gray wide-tb-100 bg-wave">
        <div class="container pos-rel">
            <div class="row">
                <div class="col-lg-5">
                    <img src="<?php echo base_url();?>assets/images/about_img_2.jpg" class="bordered-img" alt>
                </div>
                <div class="col-lg-7 ml-auto why-choose mt-5 mt-lg-0 wow fadeInRight" data-wow-duration="0" data-wow-delay="0.6s">
                    <h1 class="heading-main text-start wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">
                        <span>ABOUT US</span>
                        Welcome To Rajlaxmi Roadlines
                    </h1>
                    <p> We have Our Self vehicle Like TATA S , Mahindra Pickup, TATA 407 tempo , TATA LPT 909 , LPT 1109 ,ODC Trucks , Etc and many other vehicle are attached to our firm , in any condition we will Provide you the better transportation other than the competitors.
                    </p>
                    <p>We are Already providing  the service to Agility Logistics Pvt Ltd , C.H Robinson Worldwide ,Avignon Shipping Company , etc many other CHA Companies ,we are known for the better Transport service  into the Companies.</p>
                    <div class="skillbar-wrap mt-5">
                        <div class="clearfix">
                            Logistics
                        </div>
                        <div class="skillbar" data-percent="75%">
                            <div class="skillbar-percent">75%</div>
                            <div class="skillbar-bar"></div>
                        </div>
                    </div>
                    <div class="skillbar-wrap">
                        <div class="clearfix">
                            Truck Rental
                        </div>
                        <div class="skillbar" data-percent="50%">
                            <div class="skillbar-percent">50%</div>
                            <div class="skillbar-bar"></div>
                        </div>
                    </div>
                    <div class="skillbar-wrap">
                        <div class="clearfix">
                            Courier
                        </div>
                        <div class="skillbar" data-percent="95%">
                            <div class="skillbar-percent">95%</div>
                            <div class="skillbar-bar"></div>
                        </div>
                    </div>
                    <div class="skillbar-wrap">
                        <div class="clearfix">
                            Air Transport
                        </div>
                        <div class="skillbar" data-percent="60%">
                            <div class="skillbar-percent">60%</div>
                            <div class="skillbar-bar"></div>
                        </div>
                    </div>
                    <div class="skillbar-wrap">
                        <div class="clearfix">
                            Support
                        </div>
                        <div class="skillbar" data-percent="95%">
                            <div class="skillbar-percent">95%</div>
                            <div class="skillbar-bar"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="wide-tb-80 bg-navy-blue callout-style-1 wow fadeInUp" data-wow-duration="0" data-wow-delay="0s">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-4 col-md-12 mb-0">
                    <h4 class="h4-xl">Interested in working with Rajlaxmi Roadlines?</h4>
                </div>
                <div class="col">
                    <div class="center-text">
                        Our approach involves personalized, consultative management of suppliers.
                    </div>
                </div>
                <div class="col-sm-auto">
                    <a href="<?php echo base_url();?>contact_us" class="btn-theme bg-white light">Get In Touch <i class="icofont-rounded-right"></i></a>
                </div>
            </div>
        </div>
    </section>
</main>