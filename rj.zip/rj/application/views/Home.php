
<div class="slider bg-navy-blue">
<div id="rev_slider_1078_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" data-alias="classic4export" data-source="gallery" style="margin:0px auto;background-color:transparent;padding:0px;margin-top:0px;margin-bottom:0px;">

<div id="rev_slider_1078_1" class="rev_slider fullscreenbanner" style="display:none;" data-version="5.4.1">
<ul>
<li data-index="rs-82" data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="Power4.easeOut" data-easeout="Power4.easeOut" data-masterspeed="1000" data-thumb="../../assets/images/waterfal-100x50.jpg" data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1 data-param2 data-param3 data-param4 data-param5 data-param6 data-param7 data-param8 data-param9 data-param10 data-description data-slicey_shadow="0px 0px 50px 0px transparent">

<img src="<?php echo base_url();?>assets/images/banner_slider_4.jpg" alt data-bgposition="center center" data-kenburns="on" data-duration="7000" data-ease="Linear.easeNone" data-scalestart="100" data-scaleend="150" data-rotatestart="0" data-rotateend="0" data-blurstart="0" data-blurend="0" data-offsetstart="0 0" data-offsetend="0 0" class="rev-slidebg" data-no-retina>


<div class="tp-caption tp-resizeme NotGeneric-Title" id="slide-82-layer-2" data-blendmode="”color-dodge“" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['-70','-70','-70','-70']" data-fontsize="['70','60','60','55']" data-lineheight="['80','70','70','40']" data-width="none" data-height="none" data-whitespace="nowrap" data-type="text" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:200,&quot;speed&quot;:1000,&quot;sfx_effect&quot;:&quot;blockfromleft&quot;,&quot;sfxcolor&quot;:&quot;#ffffff&quot;,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;z:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power4.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">We
Are LogZee</div>

<div class="tp-caption medium_light_white tp-resizeme" id="slide-82-layer-3" data-blendmode="”color-dodge“" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['-10','-10','-10','-10']" data-width="none" data-height="none" data-whitespace="nowrap" data-type="text" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:500,&quot;speed&quot;:1000,&quot;sfx_effect&quot;:&quot;blockfromleft&quot;,&quot;sfxcolor&quot;:&quot;#ffffff&quot;,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;z:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power4.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-fontsize="['28','28','28','28']" data-lineheight="['34','34','34','50']">From Pickup to
Destination</div>

<div class="tp-caption tp-resizeme small_light_white " id="slide-82-layer-4" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['60','60','60','60']" data-width="none" data-height="none" data-whitespace="nowrap" data-type="text" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:600,&quot;speed&quot;:1000,&quot;sfx_effect&quot;:&quot;blockfromleft&quot;,&quot;sfxcolor&quot;:&quot;#ffffff&quot;,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;z:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power4.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-fontsize="['16','16','16','13']" data-lineheight="['30','30','30','20']">We deliver
your products on time with pure safety. Sed ut perspiciatis unde<br> omnis iste natus error
sit voluptatem accusantium doloremque laudantium,</div>

<div class="tp-caption tp-resizeme btn-theme bg-navy-blue rev-btn" id="slide-82-layer-5" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['140','140','140','140']" data-width="none" data-height="none" data-whitespace="nowrap" data-type="text" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:750,&quot;speed&quot;:1000,&quot;sfx_effect&quot;:&quot;blockfromleft&quot;,&quot;sfxcolor&quot;:&quot;#ffffff&quot;,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;z:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power4.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[30,30,30,30]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[30,30,30,30]" data-fontsize="['14','14','14','14']" data-lineheight="['16','16','16','16']">Learn More <i class="icofont-rounded-right"></i>
</div>
</li>

<li data-index="rs-3045" data-transition="zoomout" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="2000" data-thumb="rev-slider/assets/images/datcolor-100x50.jpg" data-rotate="0" data-fstransition="fade" data-fsmasterspeed="1500" data-fsslotamount="7" data-saveperformance="off" data-title="Intro" data-param1 data-param2 data-param3 data-param4 data-param5 data-param6 data-param7 data-param8 data-param9 data-param10 data-description>

<img src="<?php echo base_url();?>assets/images/banner_slider_3.jpg" alt data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>


<div class="tp-caption NotGeneric-Title tp-resizeme" id="slide-3-layer-1" data-x="left" data-hoffset="60" data-y="center" data-voffset="-120" data-width="['auto','auto','auto','auto']" data-height="['auto','auto','auto','auto']" data-transform_idle="o:1;" data-fontsize="['70','70','70','45']" data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-start="700" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 1; white-space: nowrap;">
<span class="slider-small">Ready For Any</span> <br>Obstacle
</div>

<div class="tp-caption NotGeneric-Title tp-resizeme" id="slide-3-layer-2" data-x="left" data-hoffset="60" data-y="center" data-voffset="10" data-width="['auto','auto','auto','auto']" data-height="['auto','auto','auto','auto']" data-transform_idle="o:1;" data-transform_in="x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-start="1400" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 2; white-space: nowrap; font-size: 18px; line-height: 30px;">Proin gravida
nibh vel velit auctor aliquet. Aenean sollicitudin,<br> lorem quis bibendum auctor, nisi
elit consequat ipsum, nec <br>sagittis sem nibh id elit.
</div>

<div class="tp-caption BigBold-Button rev-btn " id="slide-3-layer-3" data-x="left" data-hoffset="60" data-y="center" data-voffset="100" data-width="['auto']" data-height="['auto']" data-transform_idle="o:1;" data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:300;e:Power1.easeInOut;" data-style_hover="c:rgba(255, 255, 255, 1.00);bg:rgba(41, 46, 49, 0);bc:rgba(255, 255, 255, 1.00);cursor:pointer;" data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power3.easeInOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:[100%];s:inherit;e:inherit;" data-start="2100" data-splitin="none" data-splitout="none" data-actions="[{&quot;event&quot;:&quot;click&quot;,&quot;action&quot;:&quot;jumptoslide&quot;,&quot;slide&quot;:&quot;next&quot;,&quot;delay&quot;:&quot;&quot;}]" data-responsive_offset="on" data-responsive="off" style="z-index: 3; white-space: nowrap; font-weight: 800;background-color:rgba(41, 46, 49, 1.00);border-color:rgba(255, 255, 255, 0);outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;">
READ MORE
</div>
</li>
</ul>
<div class="tp-bannertimer tp-bottom" style="height: 7px; background-color: rgba(255, 255, 255, 0.25);">
</div>
</div>
</div>
</div>


<main id="body-content">

<section class="bg-white wide-tb-100">
<div class="container pos-rel">
<div class="row">
<div class="col-md-12 col-lg-6">
<p><img src="<?php echo base_url();?>assets/images/years_img.png" alt class="mb-5"></p>
<p>Having implemented a variety of ecological, economic and social initiatives, the family-owned
company, which has a history going back 500 years, is considered a pioneer in terms of
sustainable business today.</p>
<p>The Corporate Movie of the transport and logistics service provider Globax Logistics. GL not
only moves goods and data, but also people who are connected to the orange network.</p>
<div class="img-icon mt-4 d-flex align-items-center">
<img src="<?php echo base_url();?>assets/images/team/team-1.jpg">
<h3>
John Morise
<span>Founder & CEO</span>
</h3>
</div>
</div>

<div class="w-100 spacer-50 d-none d-md-block d-lg-none d-sm-none"></div>

<div class="col-md-12 col-lg-6">
<div class="row">

<div class="col-12 col-md-6">
<div class="icon-box-6">
<i class="icofont-box"></i>
<h3 class="h3-xs txt-blue">Packaging and Storage</h3>
<p>Praesent pellentesque diam vitae nibh aliquam faucibus.</p>
<a href="#" class="btn-arrow bg-navy-blue"><i class="icofont-swoosh-right"></i></a>
</div>
</div>


<div class="col-12 col-md-6">
<div class="icon-box-6">
<i class="icofont-safety"></i>
<h3 class="h3-xs txt-blue">Safety & Quality</h3>
<p>Praesent pellentesque diam vitae nibh aliquam faucibus.</p>
<a href="#" class="btn-arrow bg-navy-blue"><i class="icofont-swoosh-right"></i></a>
</div>
</div>


<div class="w-100 spacer-50 d-none d-md-block d-lg-block d-sm-none"></div>


<div class="col-12 col-md-6">
<div class="icon-box-6">
<i class="icofont-tree-alt"></i>
<h3 class="h3-xs txt-blue">Care for Environment</h3>
<p>Praesent pellentesque diam vitae nibh aliquam faucibus.</p>
<a href="#" class="btn-arrow bg-navy-blue"><i class="icofont-swoosh-right"></i></a>
</div>
</div>


<div class="col-12 col-md-6">
<div class="icon-box-6">
<i class="icofont-delivery-time"></i>
<h3 class="h3-xs txt-blue">Delivery On Time</h3>
<p>Praesent pellentesque diam vitae nibh aliquam faucibus.</p>
<a href="#" class="btn-arrow bg-navy-blue"><i class="icofont-swoosh-right"></i></a>
</div>
</div>

</div>
</div>
</div>
</div>
</section>


<section class="bg-light-gray wide-tb-100 bg-wave">
<div class="container pos-rel">
<div class="row">
<div class="col-lg-5">
<img src="<?php echo base_url();?>assets/images/about_img_2.jpg" class="bordered-img" alt>
</div>
<div class="col-lg-7 ml-auto why-choose mt-5 mt-lg-0 wow fadeInRight" data-wow-duration="0" data-wow-delay="0.6s">

<h1 class="heading-main text-start wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">
<span>ABOUT US</span>
Welcome To Logzee Family
</h1>

<p>Energistically utilize team driven niche markets rather than leveraged platforms.
Monotonectally restore tactical "outside the box" thinking and technically sound
deliverables.</p>
<p>Compellingly develop fully researched process improvements through innovative opportunities.
Credibly productize highly efficient potentialities for vertical core competencies. Quickly
maintain pandemic experiences rather than low-risk high-yield processes.</p>
<div class="skillbar-wrap mt-5">
<div class="clearfix">
Logistics
</div>
<div class="skillbar" data-percent="75%">
<div class="skillbar-percent">75%</div>
<div class="skillbar-bar"></div>
</div>
</div>
<div class="skillbar-wrap">
<div class="clearfix">
Truck Rental
</div>
<div class="skillbar" data-percent="50%">
<div class="skillbar-percent">50%</div>
<div class="skillbar-bar"></div>
</div>
</div>
<div class="skillbar-wrap">
<div class="clearfix">
Courier
</div>
<div class="skillbar" data-percent="95%">
<div class="skillbar-percent">95%</div>
<div class="skillbar-bar"></div>
</div>
</div>
<div class="skillbar-wrap">
<div class="clearfix">
Air Transport
</div>
<div class="skillbar" data-percent="60%">
<div class="skillbar-percent">60%</div>
<div class="skillbar-bar"></div>
</div>
</div>
<div class="skillbar-wrap">
<div class="clearfix">
Support
</div>
<div class="skillbar" data-percent="95%">
<div class="skillbar-percent">95%</div>
<div class="skillbar-bar"></div>
</div>
</div>
</div>
</div>
</div>
</section>


<section class="bg-white wide-tb-100">
<div class="container pos-rel">
<div class="row">

<div class="col-sm-12 wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">
<h1 class="heading-main">
<span>Our Goodness</span>
What Makes Us Special
</h1>
</div>

<div class="col-lg-6 ms-auto">
<div class="row">

<div class="col-12 wow fadeInUp" data-wow-duration="0" data-wow-delay="0s">
<div class="icon-box-3 mb-5 bg-light-theme">
<div class="media">
<div class="service-icon mr-5">
<i class="icofont-box bg-white"></i>
</div>
<div class="service-inner-content media-body">
<h4 class="h4-md">Packaging and Storage</h4>
<p>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere
cubilia Curae. Praesent pellentesque diam vitae nibh aliquam faucibus.
</p>
</div>
</div>
</div>
</div>


<div class="col-12 wow fadeInUp" data-wow-duration="0" data-wow-delay="0.2s">
<div class="icon-box-3 mb-5 bg-light-theme">
<div class="media">
<div class="service-icon mr-5">
<i class="icofont-shield bg-white"></i>
</div>
<div class="service-inner-content media-body">
<h4 class="h4-md">Safety & Quality</h4>
<p>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere
cubilia Curae. Praesent pellentesque diam vitae nibh aliquam faucibus.
</p>
</div>
</div>
</div>
</div>


<div class="col-12 wow fadeInUp" data-wow-duration="0" data-wow-delay="0.4s">
<div class="icon-box-3 bg-light-theme">
<div class="media">
<div class="service-icon mr-5">
<i class="icofont-tree-alt bg-white"></i>
</div>
<div class="service-inner-content media-body">
<h4 class="h4-md">Care for Environment</h4>
<p>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere
cubilia Curae. Praesent pellentesque diam vitae nibh aliquam faucibus.
</p>
</div>
</div>
</div>
</div>

</div>
</div>
<div class="img-business-man">
<img src="<?php echo base_url();?>assets/images/courier-man.png" alt>
</div>
</div>
</div>
</section>


<section class="wide-tb-100 bg-scroll counter-bg pos-rel">
<div class="bg-overlay blue opacity-50"></div>
<div class="container">
<div class="row">

<div class="col counter-style-1 col-6 col-lg-3 col-sm-6 wow fadeInLeft" data-wow-duration="0" data-wow-delay="0s">
<p><i class="icofont-google-map"></i></p>
<span class="counter">15</span>
<div>
Our Locations
</div>
</div>


<div class="col counter-style-1 col-6 col-lg-3 col-sm-6 wow fadeInLeft" data-wow-duration="0" data-wow-delay="0s">
<p><i class="icofont-globe"></i></p>
<span class="counter">110</span>
<span>+</span>
<div>
Clients Worldwide
</div>
</div>


<div class="w-100 d-none d-sm-block d-lg-none spacer-60"></div>


<div class="col counter-style-1 col-6 col-lg-3 col-sm-6 wow fadeInRight" data-wow-duration="0" data-wow-delay="0">
<p><i class="icofont-vehicle-delivery-van"></i></p>
<span class="counter">240</span>
<span>+</span>
<div>
Owned Vehicles
</div>
</div>


<div class="col counter-style-1 col-6 col-lg-3 col-sm-6 wow fadeInRight" data-wow-duration="0" data-wow-delay="0s">
<p><i class="icofont-umbrella-alt"></i></p>
<span class="counter">2340</span>
<div>
Tonnes Transported
</div>
</div>

</div>
</div>
</section>


<section class="bg-white wide-tb-100">
<div class="container pos-rel">
<div class="row">

<div class="col-sm-12 wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">
<h1 class="heading-main">
<span>our Gallery</span>
Photo Showcase
</h1>
</div>

</div>
<div id="js-styl2-mosaic" class="cbp">
<div class="cbp-item design">
<div class="gallery-link">
<a href="project-single.html" class="txt-white"><i class="icofont-external-link"></i></a>
</div>
<a href="images/portfolio/fullwidth/img-1.jpg" class="cbp-caption cbp-lightbox" data-title="Lorem ipsum">
<div class="cbp-caption-defaultWrap">
<img src="<?php echo base_url();?>assets/images/portfolio/fullwidth/img-1.jpg" alt>
</div>
<div class="cbp-caption-activeWrap">
<div class="cbp-l-caption-alignCenter">
<div class="cbp-l-caption-body">
<i class="icofont-search icofont-2x txt-white"></i>
</div>
</div>
</div>
</a>
</div>
<div class="cbp-item design">
<div class="gallery-link">
<a href="project-single.html" class="txt-white"><i class="icofont-external-link"></i></a>
</div>
<a href="images/portfolio/fullwidth/img-2.jpg" class="cbp-caption cbp-lightbox" data-title="Lorem ipsum
">
<div class="cbp-caption-defaultWrap">
<img src="<?php echo base_url();?>assets/images/portfolio/fullwidth/img-2.jpg" alt>
</div>
<div class="cbp-caption-activeWrap">
<div class="cbp-l-caption-alignCenter">
<div class="cbp-l-caption-body">
<i class="icofont-search icofont-2x txt-white"></i>
</div>
</div>
</div>
</a>
</div>
<div class="cbp-item illustration">
<div class="gallery-link">
<a href="project-single.html" class="txt-white"><i class="icofont-external-link"></i></a>
</div>
<a href="<?php echo base_url();?>assets/images/portfolio/fullwidth/img-3.jpg" class="cbp-caption cbp-lightbox" data-title="Lorem ipsum
">
<div class="cbp-caption-defaultWrap">
<img src="<?php echo base_url();?>assets/images/portfolio/fullwidth/img-3.jpg" alt>
</div>
<div class="cbp-caption-activeWrap">
<div class="cbp-l-caption-alignCenter">
<div class="cbp-l-caption-body">
<i class="icofont-search icofont-2x txt-white"></i>
</div>
</div>
</div>
</a>
</div>
<div class="cbp-item photography">
<div class="gallery-link">
<a href="project-single.html" class="txt-white"><i class="icofont-external-link"></i></a>
</div>
<a href="<?php echo base_url();?>assets/images/portfolio/fullwidth/img-7.jpg" class="cbp-caption cbp-lightbox" data-title="Lorem ipsum
">
<div class="cbp-caption-defaultWrap">
<img src="<?php echo base_url();?>assets/images/portfolio/fullwidth/img-7.jpg" alt>
</div>
<div class="cbp-caption-activeWrap">
<div class="cbp-l-caption-alignCenter">
<div class="cbp-l-caption-body">
<i class="icofont-search icofont-2x txt-white"></i>
</div>
</div>
</div>
</a>
</div>
<div class="cbp-item identity">
<div class="gallery-link">
<a href="project-single.html" class="txt-white"><i class="icofont-external-link"></i></a>
</div>
<a href="<?php echo base_url();?>assets/images/portfolio/fullwidth/img-8.jpg" class="cbp-caption cbp-lightbox" data-title="Lorem ipsum
">
<div class="cbp-caption-defaultWrap">
<img src="<?php echo base_url();?>assets/images/portfolio/fullwidth/img-8.jpg" alt>
</div>
<div class="cbp-caption-activeWrap">
<div class="cbp-l-caption-alignCenter">
<div class="cbp-l-caption-body">
<i class="icofont-search icofont-2x txt-white"></i>
</div>
</div>
</div>
</a>
</div>
<div class="cbp-item business">
<div class="gallery-link">
<a href="project-single.html" class="txt-white"><i class="icofont-external-link"></i></a>
</div>
<a href="<?php echo base_url();?>assets/images/portfolio/fullwidth/img-9.jpg" class="cbp-caption cbp-lightbox" data-title="Lorem ipsum
">
<div class="cbp-caption-defaultWrap">
<img src="<?php echo base_url();?>assets/images/portfolio/fullwidth/img-9.jpg" alt>
</div>
<div class="cbp-caption-activeWrap">
<div class="cbp-l-caption-alignCenter">
<div class="cbp-l-caption-body">
<i class="icofont-search icofont-2x txt-white"></i>
</div>
</div>
</div>
</a>
</div>
<div class="cbp-item photography">
<div class="gallery-link">
<a href="project-single.html" class="txt-white"><i class="icofont-external-link"></i></a>
</div>
<a href="<?php echo base_url();?>assets/images/portfolio/fullwidth/img-10.jpg" class="cbp-caption cbp-lightbox" data-title="Lorem ipsum">
<div class="cbp-caption-defaultWrap">
<img src="<?php echo base_url();?>assets/images/portfolio/fullwidth/img-10.jpg" alt>
</div>
<div class="cbp-caption-activeWrap">
<div class="cbp-l-caption-alignCenter">
<div class="cbp-l-caption-body">
<i class="icofont-search icofont-2x txt-white"></i>
</div>
</div>
</div>
</a>
</div>
<div class="cbp-item business">
<div class="gallery-link">
<a href="project-single.html" class="txt-white"><i class="icofont-external-link"></i></a>
</div>
<a href="<?php echo base_url();?>assets/images/portfolio/fullwidth/img-11.jpg" class="cbp-caption cbp-lightbox" data-title="Lorem ipsum">
<div class="cbp-caption-defaultWrap">
<img src="<?php echo base_url();?>assets/images/portfolio/fullwidth/img-11.jpg" alt>
</div>
<div class="cbp-caption-activeWrap">
<div class="cbp-l-caption-alignCenter">
<div class="cbp-l-caption-body">
<i class="icofont-search icofont-2x txt-white"></i>
</div>
</div>
</div>
</a>
</div>
</div>
</div>
</section>


<section class="bg-light-theme wide-tb-100 pb-5 why-choose">
<div class="container pos-rel">
<div class="contact-map-bg">
<img src="<?php echo base_url();?>assets/images/map-bg.png" alt>
</div>
<div class="row piecharts" id="pie-charts">

<div class="col-sm-12 wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">
<h1 class="heading-main">
<span>Looking for more?</span>
Watch Our Intro Video
</h1>
</div>

<div class="col-lg-6 col-md-10 mx-auto">
<div class="row">
<div class="col-lg-4 col-md-4 col-sm-4 col-6 mb-0">
<span class="chart" data-percent="90">
<span class="percent"></span>
</span>
<div class="skill-name">Road Transport</div>
</div>
<div class="col-lg-4 col-md-4 col-sm-4 col-6 mb-0">
<span class="chart" data-percent="90">
<span class="percent"></span>
</span>
<div class="skill-name">Logistics</div>
</div>
<div class="col-lg-4 col-md-4 col-sm-4 col-12 mb-0">
<span class="chart" data-percent="95">
<span class="percent"></span>
</span>
<div class="skill-name">Truck Rental</div>
</div>
</div>
</div>
</div>
</section>
<section class="wide-tb-60 p-0 bg-light-theme">
<div class="container">
<div class="row">
<div class="col-lg-8 mx-auto col-md-10 wow pulse animated" data-wow-duration="0" data-wow-delay="0.7s">
<div class="bg-fixed pos-rel video-popup">
<div class="bg-overlay black opacity-50"></div>
<div class="zindex-fixed pos-rel">
<a href="#" class="play-video"><i class="icofont-play icofont-4x"></i></a>
</div>
</div>
</div>
</div>
</div>
</section>


<section class="wide-tb-100 mb-spacer-md">
<div class="container wide-tb-100 pb-0">
<div class="row">

<div class="col-sm-12 wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">
<h1 class="heading-main">
<span>What Our</span>
Customers Saying
</h1>
</div>

<div class="col-sm-12">
<div class="owl-carousel owl-theme" id="home-client-testimonials">

<div class="item">
<div class="client-testimonial bg-wave">
<div class="media">
<div class="client-testimonial-icon rounded-circle bg-navy-blue">
<img src="<?php echo base_url();?>assets/images/team_1.jpg" alt>
</div>
<div class="client-inner-content media-body">
<p>Far far away, behind the word mountains, far from the countries Vokalia
and Consonantia, there live the blind texts. Aliquam gravida, urna quis
ornare imperdiet, </p>
<footer class="blockquote-footer"><cite title="Source Title">John Gerry
Design Hunt</cite></footer>
</div>
</div>
</div>
</div>


<div class="item">
<div class="client-testimonial bg-wave">
<div class="media">
<div class="client-testimonial-icon rounded-circle bg-navy-blue">
<img src="<?php echo base_url();?>assets/images/team_2.jpg" alt>
</div>
<div class="client-inner-content media-body">
<p>Far far away, behind the word mountains, far from the countries Vokalia
and Consonantia, there live the blind texts. Aliquam gravida, urna quis
ornare imperdiet, </p>
<footer class="blockquote-footer"><cite title="Source Title">John Gerry
Design Hunt</cite></footer>
</div>
</div>
</div>
</div>


<div class="item">
<div class="client-testimonial bg-wave">
<div class="media">
<div class="client-testimonial-icon rounded-circle bg-navy-blue">
<img src="<?php echo base_url();?>assets/images/team_3.jpg" alt>
</div>
<div class="client-inner-content media-body">
<p>Far far away, behind the word mountains, far from the countries Vokalia
and Consonantia, there live the blind texts. Aliquam gravida, urna quis
ornare imperdiet, </p>
<footer class="blockquote-footer"><cite title="Source Title">John Gerry
Design Hunt</cite></footer>
</div>
</div>
</div>
</div>

</div>
</div>
</div>
</div>
</section>


<section class="wide-tb-80 bg-navy-blue callout-style-1 wow fadeInUp" data-wow-duration="0" data-wow-delay="0s">
<div class="container">
<div class="row align-items-center">
<div class="col-lg-4 col-md-12 mb-0">
<h4 class="h4-xl">Interested in working with Logzee?</h4>
</div>
<div class="col">
<div class="center-text">
We don’t just manage suppliers, we micro-manage them. We have a consultative, personalized
approach
</div>
</div>
<div class="col-sm-auto">
<a href="#" class="btn-theme bg-white light">Get In Touch <i class="icofont-rounded-right"></i></a>
</div>
</div>
</div>
</section>


<section class="wide-tb-100">
<div class="container">
<div class="row">

<div class="col-sm-12 wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">
<h1 class="heading-main">
<span>COMPANY'S NEWS</span>
Recent Posts
</h1>
</div>


<div class="col-sm-12 col-md-4 wow fadeInLeft" data-wow-duration="0" data-wow-delay="0.1s">
<div class="blog-warp">
<img src="<?php echo base_url();?>assets/images/blog_img_1.jpg" alt class="rounded">
<div class="meta-box"><a href="#">Business</a> <span>/</span> September 28, 2018</div>
<h4 class="h4-md mb-3"><a href="#">Freight Payment and Auditing Services</a></h4>
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque
laudantiumg</p>
</div>
</div>


<div class="col-sm-12 col-md-4 wow fadeInUp" data-wow-duration="0" data-wow-delay="0.1s">
<div class="blog-warp">
<img src="<?php echo base_url();?>assets/images/blog_img_2.jpg" alt class="rounded">
<div class="meta-box"><a href="#">Business</a> <span>/</span> September 28, 2018</div>
<h4 class="h4-md mb-3"><a href="#">Freight Payment and Auditing Services</a></h4>
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque
laudantiumg</p>
</div>
</div>


<div class="col-sm-12 col-md-4 wow fadeInRight" data-wow-duration="0" data-wow-delay="0.1s">
<div class="blog-warp">
<img src="<?php echo base_url();?>assets/images/blog_img_3.jpg" alt class="rounded">
<div class="meta-box"><a href="#">Business</a> <span>/</span> September 28, 2018</div>
<h4 class="h4-md mb-3"><a href="#">Freight Payment and Auditing Services</a></h4>
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque
laudantiumg</p>
</div>
</div>

</div>
</div>
</section>


<section class="wide-tb-100 bg-fixed clients-bg pos-rel">
<div class="bg-overlay blue opacity-80"></div>
<div class="container">
<div class="row">

<div class="col-sm-12 wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">
<h1 class="heading-main">
<span>SOME OF OUR</span>
Clients
</h1>
</div>

<div class="col-sm-12 wow fadeInUp" data-wow-duration="0" data-wow-delay="0.2s">
<div class="owl-carousel owl-theme" id="home-clients">

<div class="item">
<img src="<?php echo base_url();?>assets/images/clients/client1.png" alt>
</div>


<div class="item">
<img src="<?php echo base_url();?>assets/images/clients/client2.png" alt>
</div>


<div class="item">
<img src="<?php echo base_url();?>assets/images/clients/client3.png" alt>
</div>


<div class="item">
<img src="<?php echo base_url();?>assets/images/clients/client4.png" alt>
</div>


<div class="item">
<img src="<?php echo base_url();?>assets/images/clients/client5.png" alt>
</div>


<div class="item">
<img src="<?php echo base_url();?>assets/images/clients/client6.png" alt>
</div>

</div>
</div>
</div>
</div>
</section>


<section class="map-bg">
<div class="contact-details row d-flex">
<div class="col">
<h4>Germany</h4>
<p><i class="icofont-phone"></i> +1 (408) 786 - 5117</p>
<div class="text-nowrap"><i class="icofont-email"></i> <a href="#"><span class="__cf_email__" data-cfemail="761113041b17180f361a19110c13135815191b">[email&#160;protected]</span></a></div>
</div>
<div class="col">
<h4>Spain</h4>
<p><i class="icofont-phone"></i> +1 (408) 786 - 5117</p>
<div class="text-nowrap"><i class="icofont-email"></i> <a href="#"><span class="__cf_email__" data-cfemail="9eedeefff7f0def2f1f9e4fbfbb0fdf1f3">[email&#160;protected]</span></a></div>
</div>
</div>
<div id="map-holder" class="pos-rel">
<div id="map_extended">
<p>This will be replaced with the Google Map.</p>
</div>
</div>

</section>
</main>

