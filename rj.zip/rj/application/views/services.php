
<div class="slider bg-navy-blue bg-fixed pos-rel breadcrumbs-page">
<div class="container">
<nav aria-label="breadcrumb">
<ol class="breadcrumb">
<li class="breadcrumb-item"><a href="#"><i class="icofont-home"></i></a></li>
<li class="breadcrumb-item"><a href="#">Pages</a></li>
<li class="breadcrumb-item active" aria-current="page">Our Services</li>
</ol>
</nav>
<h1>Our Services</h1>
<div class="breadcrumbs-description">
Our global network and full-service team of airfreight and expedited freight professionals are ready to
help.
</div>
</div>
</div>


<main id="body-content">

<section class="wide-tb-80 bg-fixed what-we-offer">
<div class="container pos-rel">
<div class="row align-items-center">
<div class="col-md-6">
<h2 class="mb-4 fw-7 txt-blue wow fadeInLeft" data-wow-duration="0" data-wow-delay="0s">
Quality <span class="fw-6 txt-orange">and</span> Performance <br><span class="fw-6 txt-orange">at the right price</span>
</h2>
<p class="wow fadeInLeft" data-wow-duration="0" data-wow-delay="0.2s">Energistically utilize
team driven niche markets rather than leveraged platforms. Monotonectally restore tactical
"outside the box" thinking and technically sound deliverables. </p>
<p class="wow fadeInLeft" data-wow-duration="0" data-wow-delay="0.4s">Compellingly develop fully
researched process improvements through innovative opportunities. Credibly productize highly
efficient potentialities for vertical core competencies. Quickly maintain pandemic
experiences rather than low-risk high-yield processes.</p>
</div>
<div class="col-md-6">
</div>
</div>
</div>
</section>


<section class="bg-white wide-tb-100">
<div class="container">
<div class="row">

<div class="col-sm-12 wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">
<h1 class="heading-main">
<span>what we offer</span>
Our Main Services
</h1>
</div>


<div class="col-md-4 wow fadeInUp" data-wow-duration="0" data-wow-delay="0.1s">
<a href="service-details.html">
<div class="icon-box-1">
<img src="<?php echo base_url();?>assets/images/icon-box-1.jpg" alt>
<div class="text">
<i class="icofont-vehicle-delivery-van"></i>
GROUND DELIVERY
</div>
</div>
</a>
</div>


<div class="col-md-4 wow fadeInUp" data-wow-duration="0" data-wow-delay="0.4s">
<a href="service-details.html">
<div class="icon-box-1">
<img src="<?php echo base_url();?>assets/images/icon-box-2.jpg" alt>
<div class="text">
<i class="icofont-airplane-alt"></i>
AIR DELIVERY
</div>
</div>
</a>
</div>


<div class="col-md-4 wow fadeInUp" data-wow-duration="0" data-wow-delay="0.6s">
<a href="service-details.html">
<div class="icon-box-1">
<img src="<?php echo base_url();?>assets/images/icon-box-3.jpg" alt>
<div class="text">
<i class="icofont-ship"></i>
SEA DELIVERY
</div>
</div>
</a>
</div>

</div>
</div>
</section>


<section class="bg-light-theme wide-tb-100">
<div class="container pos-rel">
<div class="row">

<div class="col-sm-12 wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">
<h1 class="heading-main">
<span>Our Goodness</span>
What Makes Us Special
</h1>
</div>

<div class="col-lg-6 ms-auto">
<div class="row">

<div class="col-12 wow fadeInUp" data-wow-duration="0" data-wow-delay="0s">
<div class="icon-box-3 mb-5 bg-light-theme">
<div class="media">
<div class="service-icon mr-5">
<i class="icofont-box"></i>
</div>
<div class="service-inner-content media-body">
<h4 class="h4-md">Packaging and Storage</h4>
<p>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere
cubilia Curae. Praesent pellentesque diam vitae nibh aliquam faucibus.
</p>
</div>
</div>
</div>
</div>


<div class="col-12 wow fadeInUp" data-wow-duration="0" data-wow-delay="0.2s">
<div class="icon-box-3 mb-5 bg-light-theme">
<div class="media">
<div class="service-icon mr-5">
<i class="icofont-shield"></i>
</div>
<div class="service-inner-content media-body">
<h4 class="h4-md">Safety & Quality</h4>
<p>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere
cubilia Curae. Praesent pellentesque diam vitae nibh aliquam faucibus.
</p>
</div>
</div>
</div>
</div>


<div class="col-12 wow fadeInUp" data-wow-duration="0" data-wow-delay="0.4s">
<div class="icon-box-3 bg-light-theme">
<div class="media">
<div class="service-icon mr-5">
<i class="icofont-tree-alt"></i>
</div>
<div class="service-inner-content media-body">
<h4 class="h4-md">Care for Environment</h4>
<p>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere
cubilia Curae. Praesent pellentesque diam vitae nibh aliquam faucibus.
</p>
</div>
</div>
</div>
</div>

</div>
</div>
<div class="img-business-man">
<img src="<?php echo base_url();?>assets/images/courier-man.png" alt>
</div>
</div>
</div>
</section>


<section class="wide-tb-100">
<div class="container">
<div class="row">
<div class="col-lg-7 ms-lg-auto pos-rel col-md-12">

<h1 class="heading-main text-start">
<span>get updates</span>
Tracking Your Freight
</h1>


<form class="form-inline tracking">
<input type="text" class="form-control mb-2 mr-sm-2 col" placeholder="Enter order number">
<button type="submit" class="btn btn-theme bg-orange mb-2 ml-3">Check Now <i class="icofont-rounded-right"></i></button>
</form>


<div class="forklift-image wow slideInLeft" data-wow-duration="0" data-wow-delay="0s">
<img src="<?php echo base_url();?>assets/images/forklift_Image.png" alt>
</div>

</div>
</div>
</div>
</section>


<section class="bg-light-gray">
<div class="container-fluid">
<div class="row align-items-center no-gutters">

<div class="col-lg-4 text-center">
<div class="px-5 wide-tb-100">
<div class="service-icon mx-auto mb-5 icon-box-5">
<i class="icofont-glass"></i>
</div>
<h4 class="h4-md fw-7 txt-blue">SAFE & SECURE</h4>
Nunc non mollis nulla. Sed tconsectetur elit id mi consectetur bibendum.
</div>
</div>


<div class="col-lg-4 text-center clients-bg pos-rel txt-white">
<div class="bg-overlay black opacity-40"></div>
<div class="px-5 wide-tb-100" style="position: relative; z-index: 999;">
<div class="service-icon mx-auto mb-5 icon-box-5">
<i class="icofont-delivery-time"></i>
</div>
<h4 class="h4-md fw-7">FAST DELIVERY</h4>
Nunc non mollis nulla. Sed tconsectetur elit id mi consectetur bibendum.
</div>
</div>


<div class="col-lg-4 text-center">
<div class="px-5 wide-tb-100">
<div class="service-icon mx-auto mb-5 icon-box-5">
<i class="icofont-live-support"></i>
</div>
<h4 class="h4-md fw-7 txt-blue">24/7 Support</h4>
Nunc non mollis nulla. Sed tconsectetur elit id mi consectetur bibendum.
</div>
</div>

</div>
</div>
</section>


<section class="wide-tb-100">
<div class="container">
<div class="row">

<div class="col-sm-12 wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">
<h1 class="heading-main">
<span>What Our</span>
Customers Saying
</h1>
</div>

<div class="col-sm-12">
<div class="owl-carousel owl-theme" id="home-client-testimonials">

<div class="item">
<div class="client-testimonial bg-wave">
<div class="media">
<div class="client-testimonial-icon rounded-circle bg-navy-blue">
<img src="<?php echo base_url();?>assets/images/team_1.jpg" alt>
</div>
<div class="client-inner-content media-body">
<p>Far far away, behind the word mountains, far from the countries Vokalia
and Consonantia, there live the blind texts. Aliquam gravida, urna quis
ornare imperdiet, </p>
<footer class="blockquote-footer"><cite title="Source Title">John Gerry
Design Hunt</cite></footer>
</div>
</div>
</div>
</div>


<div class="item">
<div class="client-testimonial bg-wave">
<div class="media">
<div class="client-testimonial-icon rounded-circle bg-navy-blue">
<img src="<?php echo base_url();?>assets/images/team_2.jpg" alt>
</div>
<div class="client-inner-content media-body">
<p>Far far away, behind the word mountains, far from the countries Vokalia
and Consonantia, there live the blind texts. Aliquam gravida, urna quis
ornare imperdiet, </p>
<footer class="blockquote-footer"><cite title="Source Title">John Gerry
Design Hunt</cite></footer>
</div>
</div>
</div>
</div>


<div class="item">
<div class="client-testimonial bg-wave">
<div class="media">
<div class="client-testimonial-icon rounded-circle bg-navy-blue">
<img src="<?php echo base_url();?>assets/images/team_3.jpg" alt>
</div>
<div class="client-inner-content media-body">
<p>Far far away, behind the word mountains, far from the countries Vokalia
and Consonantia, there live the blind texts. Aliquam gravida, urna quis
ornare imperdiet, </p>
<footer class="blockquote-footer"><cite title="Source Title">John Gerry
Design Hunt</cite></footer>
</div>
</div>
</div>
</div>

</div>
</div>
</div>
</div>
</section>


<section class="wide-tb-100 bg-light-theme pos-rel">
<div class="container">
<div class="row">

<div class="col-sm-12 wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">
<h1 class="heading-main">
<span>SOME OF OUR</span>
Clients
</h1>
</div>

<div class="col-sm-12">
<div class="owl-carousel owl-theme" id="home-clients">

<div class="item bg-white">
<img src="asse<?php echo base_url();?>assetsts/images/clients/client1.png" alt>
</div>


<div class="item bg-white">
<img src="<?php echo base_url();?>assets/images/clients/client2.png" alt>
</div>


<div class="item bg-white">
<img src="<?php echo base_url();?>assets/images/clients/client3.png" alt>
</div>


<div class="item bg-white">
<img src="<?php echo base_url();?>assets/images/clients/client4.png" alt>
</div>


<div class="item bg-white">
<img src="<?php echo base_url();?>assets/images/clients/client5.png" alt>
</div>


<div class="item bg-white">
<img src="<?php echo base_url();?>assets/images/clients/client6.png" alt>
</div>

</div>
</div>
</div>
</div>
</section>


<section class="wide-tb-80 bg-scroll bg-img-6 pos-rel callout-style-1">
<div class="bg-overlay blue opacity-60"></div>
<div class="container">
<div class="row align-items-center">
<div class="col-lg-4 col-md-12 mb-0">
<h4 class="h4-xl">Interested in working with Logzee?</h4>
</div>
<div class="col">
<div class="center-text">
We don’t just manage suppliers, we micro-manage them. We have a consultative, personalized
approach
</div>
</div>
<div class="col-sm-auto">
<a href="#" class="btn btn-theme bg-white bordered">Get In Touch <i class="icofont-rounded-right"></i></a>
</div>
</div>
</div>
</section>

</main>

<section class="wide-tb-50 pb-0 bg-light-theme footer-subscribe">
<div class="container wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">
<div class="row">
<div class="col-sm-12 d-flex col-md-12 col-lg-6 offset-lg-3">
<div class="d- align-items-center d-sm-inline-flex  w-100">
<div class="head">
<span class="d-block">SUBSCRIBE For</span> NEWSLETTER
</div>
<form class="flex-nowrap col ms-3">
<input type="text" class="form-control" placeholder="Enter your email">
<button type="submit" class="btn btn-theme bg-navy-blue">SUBSCRIBE</i></button>
</form>
</div>
</div>
</div>
</div>
</section>

