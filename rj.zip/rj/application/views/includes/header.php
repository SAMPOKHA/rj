<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="viewport" content="width=device-width, initial-scale=1.0 user-scalable=no" />
        <title>Logzee - A Logistic Cargo Bootstrap HTML Template</title>
        <meta name="author" content="Mannat Studio">
        <meta name="description" content="Logzee is a Responsive HTML5 Template for Logistic and Cargo related services.">
        <meta name="keywords" content="Logzee, responsive, html5, business, cargo, chain supply, company, corporate, expedition, freight, logistics, packaging, services, shipping, transport, transportation, trucking, warehousing">
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url();?>assets/images/favicon.ico">
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url();?>assets/images/favicon.ico">
        <link href="<?php echo base_url();?>assets/css/theme-plugins.min.css" rel="stylesheet">
        <link href="<?php echo base_url();?>assets/css/style.css" rel="stylesheet">
        <link href="<?php echo base_url();?>assets/css/responsive.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/revolution/css/layers.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/revolution/css/navigation.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/revolution/css/settings.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/revolution/fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/revolution/fonts/font-awesome/css/font-awesome.css">
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        <div id="pageloader">
            <div class="loader-item">
                <div class="loader">
                    <div class="spin"></div>
                    <div class="bounce"></div>
                </div>
            </div>
        </div>
        <header class="header-one wow fadeInDown">
            <div class="d-flex align-items-center text-md-left top-bar">
                <div class="container px-0">
                    <div class="row align-items-center">
                        <div class="col d-flex">
                            <div class="top-text">
                                <small class="txt-black">Address</small>
                                254 Street Avenue, LA US
                            </div>
                            <div class="top-text">
                                <small class="txt-black">Emaii Us</small>
                                <a href="#"><span class="__cf_email__" data-cfemail="4f3c3a3f3f203d3b0f232028352a2a612c2022">[email&#160;protected]</span></a>
                            </div>
                            <div class="top-text">
                                <small class="txt-black">Phone Number</small>
                                +88 (0) 202 0000 001
                            </div>
                        </div>
                        <div class="col-md-auto d-flex">
                            
                            <div class="d-inline-flex request-btn ms-2">
                                <a class="btn-theme icon-left bg-orange no-shadow d-none d-lg-inline-block align-self-center" href="#" role="button" data-bs-toggle="modal" data-bs-target="#request_popup"><i class="icofont-page"></i> Request Quote</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <nav class="header-fullpage navbar navbar-expand-lg nav-light">
                <div class="container text-nowrap bdr-nav px-0">
                    <div class="d-flex mr-auto">
                        <a class="navbar-brand rounded-bottom light-bg" href="index.html">
                        <img src="<?php echo base_url();?>assets/images/logo_white.svg" alt>
                        </a>
                    </div>
                    <span class="order-lg-last d-inline-flex request-btn">
                    <a class="nav-link" href="#" id="search_home"><i class="icofont-search"></i></a>
                    </span>
                    <button class="navbar-toggler x collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarCollapse">
                        <ul class="navbar-nav ms-auto mb-2 mb-md-0">
                            <li class="nav-item dropdown">
                                <a class="nav-link" href="<?php echo base_url();?>" data-bs-toggle="dropdown" aria-expanded="false">Home <i class="icofont-rounded-down"></i></a>
                                
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link" href="<?php echo base_url();?>about_us" data-bs-toggle="dropdown" aria-expanded="false">About Us <i class="icofont-rounded-down"></i></a>
                                
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link" href="<?php echo base_url();?>projects" data-bs-toggle="dropdown" aria-expanded="false">Projects <i class="icofont-rounded-down"></i></a>
                                
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link" href="<?php echo base_url();?>services" data-bs-toggle="dropdown" aria-expanded="false">Blog <i class="icofont-rounded-down"></i></a>
                                
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link" href="<?php echo base_url();?>contact_us" data-bs-toggle="dropdown" aria-expanded="false">Contact <i class="icofont-rounded-down"></i></a>
                                
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </header>