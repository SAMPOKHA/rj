
<div class="slider bg-navy-blue bg-fixed pos-rel breadcrumbs-page">
<div class="container">
<nav aria-label="breadcrumb">
<ol class="breadcrumb">
<li class="breadcrumb-item"><a href="#"><i class="icofont-home"></i></a></li>
<li class="breadcrumb-item"><a href="#">Pages</a></li>
<li class="breadcrumb-item active" aria-current="page">Gallery grid</li>
</ol>
</nav>
<h1>Gallery grid</h1>
<div class="breadcrumbs-description">
Iterative approaches to corporate strategy foster collaborative thinking to further the overall value
proposition.
</div>
</div>
</div>


<main id="body-content">

<section class="wide-tb-80">
<div class="container">
<div id="js-grid-juicy-projects" class="cbp">
<div class="cbp-item rounded design">
<div class="gallery-link">
<a href="project-single.html" class="txt-white"><i class="icofont-external-link"></i></a>
</div>
<a href="<?php echo base_url();?>assets/images/portfolio/3col-1.jpg" class="cbp-caption cbp-lightbox" data-title="Lorem ipsum">
<div class="cbp-caption-defaultWrap">
<img src="<?php echo base_url();?>assets/images/portfolio/3col-1.jpg" alt>
</div>
<div class="cbp-caption-activeWrap">
<div class="cbp-l-caption-alignCenter">
<div class="cbp-l-caption-body">
<i class="icofont-search icofont-2x txt-white"></i>
</div>
</div>
</div>
</a>
</div>
<div class="cbp-item rounded design">
<div class="gallery-link">
<a href="project-single.html" class="txt-white"><i class="icofont-external-link"></i></a>
</div>
<a href="<?php echo base_url();?>assets/images/portfolio/3col-2.jpg" class="cbp-caption cbp-lightbox" data-title="Lorem ipsum
">
<div class="cbp-caption-defaultWrap">
<img src="<?php echo base_url();?>assets/images/portfolio/3col-2.jpg" alt>
</div>
<div class="cbp-caption-activeWrap">
<div class="cbp-l-caption-alignCenter">
<div class="cbp-l-caption-body">
<i class="icofont-search icofont-2x txt-white"></i>
</div>
</div>
</div>
</a>
</div>
<div class="cbp-item rounded illustration">
<div class="gallery-link">
<a href="project-single.html" class="txt-white"><i class="icofont-external-link"></i></a>
</div>
<a href="<?php echo base_url();?>assets/images/portfolio/3col-3.jpg" class="cbp-caption cbp-lightbox" data-title="Lorem ipsum
">
<div class="cbp-caption-defaultWrap">
<img src="<?php echo base_url();?>assets/images/portfolio/3col-3.jpg" alt>
</div>
<div class="cbp-caption-activeWrap">
<div class="cbp-l-caption-alignCenter">
<div class="cbp-l-caption-body">
<i class="icofont-search icofont-2x txt-white"></i>
</div>
</div>
</div>
</a>
</div>
<div class="cbp-item rounded photography">
<div class="gallery-link">
<a href="project-single.html" class="txt-white"><i class="icofont-external-link"></i></a>
</div>
<a href="<?php echo base_url();?>assets/images/portfolio/3col-4.jpg" class="cbp-caption cbp-lightbox" data-title="Lorem ipsum
">
<div class="cbp-caption-defaultWrap">
<img src="<?php echo base_url();?>assets/images/portfolio/3col-4.jpg" alt>
</div>
<div class="cbp-caption-activeWrap">
<div class="cbp-l-caption-alignCenter">
<div class="cbp-l-caption-body">
<i class="icofont-search icofont-2x txt-white"></i>
</div>
</div>
</div>
</a>
</div>
<div class="cbp-item rounded identity">
<div class="gallery-link">
<a href="project-single.html" class="txt-white"><i class="icofont-external-link"></i></a>
</div>
<a href="<?php echo base_url();?>assets/images/portfolio/3col-5.jpg" class="cbp-caption cbp-lightbox" data-title="Lorem ipsum
">
<div class="cbp-caption-defaultWrap">
<img src="<?php echo base_url();?>assets/images/portfolio/3col-5.jpg" alt>
</div>
<div class="cbp-caption-activeWrap">
<div class="cbp-l-caption-alignCenter">
<div class="cbp-l-caption-body">
<i class="icofont-search icofont-2x txt-white"></i>
</div>
</div>
</div>
</a>
</div>
<div class="cbp-item rounded business">
<div class="gallery-link">
<a href="project-single.html" class="txt-white"><i class="icofont-external-link"></i></a>
</div>
<a href="<?php echo base_url();?>assets/images/portfolio/3col-6.jpg" class="cbp-caption cbp-lightbox" data-title="Lorem ipsum
">
<div class="cbp-caption-defaultWrap">
<img src="<?php echo base_url();?>assets/images/portfolio/3col-6.jpg" alt>
</div>
<div class="cbp-caption-activeWrap">
<div class="cbp-l-caption-alignCenter">
<div class="cbp-l-caption-body">
<i class="icofont-search icofont-2x txt-white"></i>
</div>
</div>
</div>
</a>
</div>
<div class="cbp-item rounded photography">
<div class="gallery-link">
<a href="project-single.html" class="txt-white"><i class="icofont-external-link"></i></a>
</div>
<a href="<?php echo base_url();?>assets/images/portfolio/3col-7.jpg" class="cbp-caption cbp-lightbox" data-title="Lorem ipsum">
<div class="cbp-caption-defaultWrap">
<img src="<?php echo base_url();?>assets/images/portfolio/3col-7.jpg" alt>
</div>
<div class="cbp-caption-activeWrap">
<div class="cbp-l-caption-alignCenter">
<div class="cbp-l-caption-body">
<i class="icofont-search icofont-2x txt-white"></i>
</div>
</div>
</div>
</a>
</div>
<div class="cbp-item rounded business">
<div class="gallery-link">
<a href="project-single.html" class="txt-white"><i class="icofont-external-link"></i></a>
</div>
<a href="<?php echo base_url();?>assets/images/portfolio/3col-8.jpg" class="cbp-caption cbp-lightbox" data-title="Lorem ipsum">
<div class="cbp-caption-defaultWrap">
<img src="<?php echo base_url();?>assets/images/portfolio/3col-8.jpg" alt>
</div>
<div class="cbp-caption-activeWrap">
<div class="cbp-l-caption-alignCenter">
<div class="cbp-l-caption-body">
<i class="icofont-search icofont-2x txt-white"></i>
</div>
</div>
</div>
</a>
</div>
<div class="cbp-item rounded business">
<div class="gallery-link">
<a href="project-single.html" class="txt-white"><i class="icofont-external-link"></i></a>
</div>
<a href="<?php echo base_url();?>assets/images/portfolio/3col-9.jpg" class="cbp-caption cbp-lightbox" data-title="Lorem ipsum">
<div class="cbp-caption-defaultWrap">
<img src="<?php echo base_url();?>assets/images/portfolio/3col-9.jpg" alt>
</div>
<div class="cbp-caption-activeWrap">
<div class="cbp-l-caption-alignCenter">
<div class="cbp-l-caption-body">
<i class="icofont-search icofont-2x txt-white"></i>
</div>
</div>
</div>
</a>
</div>
</div>
</div>
</section>

</main>

<section class="wide-tb-50 pb-0 bg-light-theme footer-subscribe">
<div class="container wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">
<div class="row">
<div class="col-sm-12 d-flex col-md-12 col-lg-6 offset-lg-3">
<div class="d- align-items-center d-sm-inline-flex  w-100">
<div class="head">
<span class="d-block">SUBSCRIBE For</span> NEWSLETTER
</div>
<form class="flex-nowrap col ms-3">
<input type="text" class="form-control" placeholder="Enter your email">
<button type="submit" class="btn btn-theme bg-navy-blue">SUBSCRIBE</i></button>
</form>
</div>
</div>
</div>
</div>
</section>


